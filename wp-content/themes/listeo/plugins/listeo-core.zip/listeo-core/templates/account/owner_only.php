<div class="row">
<div class="col-md-12">
	<div class="notification success closeable margin-bottom-30">
		<p><?php esc_html_e('Sorry, you can\'t view this page as Guest, register Owner account to get access.','listeo_core' ); ?></p>
	</div>
</div>
</div>